(() => {
  // src/library/boomiapp/content/contentScript.js
  var loadScript = (url) => {
    let body = document.getElementsByTagName("body")[0];
    let script = document.createElement("script");
    script.setAttribute("type", "text/javascript");
    script.setAttribute("src", chrome.runtime.getURL(url));
    body.appendChild(script);
  };
  loadScript("./library/boomiapp/page/fullscreen.js");
  (function() {
    var script = document.createElement("script");
    script.textContent = `
    window.BoomiPlatform = {};
    window.addEventListener("message", function (e) {
      if (e.data.BoomiPlatformconfig) {
        Object.assign(window.BoomiPlatform, e.data);
      }
    }, false);
  `;
    document.getElementsByTagName("body")[0].appendChild(script);
  })();
  var org_title = document.title;
  var wait_for_load = setInterval(() => {
    if (org_title != document.title) {
      clearInterval(wait_for_load);
      updateFullscreenConfig();
      var platformStatus = document.evaluate(
        "//a[text()='Platform Status & Announcements']",
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      ).singleNodeValue;
      fetch("https://status.boomi.com/api/v2/status.json").then((res) => res.json()).then((out) => {
        if (out.status.description === "All Systems Operational" && platformStatus) {
          platformStatus.innerHTML = `<a href="https://status.boomi.com/" target="_blank"><p><b>Platform Status: </b><b style="color: green;"> All Operational</b></p></a>`;
        } else {
          platformStatus.innerHTML = `<a href="https://status.boomi.com/" target="_blank"><p><b>Platform Status: </b><b class="boomiDown" style="color: red;"> ${out.status.description}</b></p></a>`;
        }
        document.getElementById("footer_links").insertAdjacentHTML(
          "afterbegin",
          `
            <li><a class="alternate_link" target="_blank" href="https://chrome.google.com/webstore/detail/boomi-platform-enhancer/behhfojpggobllhaifocfcampokbfhko/">Boomi Platform Enhancer v${chrome.runtime.getManifest().version} loaded</a></li>
            `
        );
      }).catch((err) => console.error(err));
    }
  }, 250);
  var updateFullscreenConfig = () => {
    chrome.storage.sync.get(
      [
        "full_screen_shortcut",
        "full_screen_shortcut_alt",
        "full_screen_shortcut_ctrl",
        "full_screen_shortcut_shift"
      ],
      (config) => {
        window.postMessage(
          Object.assign({ BoomiPlatformconfig: true }, config)
        );
      }
    );
  };
  chrome.storage.onChanged.addListener((e) => {
    if (e.headerVisible || e.headerVisible === "false") {
      return;
    }
    let alert_html = `
    <div style="left: 618px; top: 139px; visibility: visible; position: absolute; overflow: visible;" class="center_panel BoomiUpdateOverlay"
    id="popup_on_popup_content" role="dialog" aria-modal="true">
    <div class="popupContent">
        <div class="modal modal_top">
            <div class="modal_contents">
                <div class="margin_popup_contents notification_min_width" style="width: 440px;">
                    <div class="form_header" style="display: none;" aria-hidden="true">
                        <div class="form_title no_required">
                            <div class="form_title_top"><svg
                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15"
                                        class="svg-infoicon size16x16" style="width: 16px; height: 16px;">
                                        <title>Extension Update Information</title>
                                        <path class="svg-background-invert"
                                            d="M7.92.5a7.24,7.24,0,0,1,5.31,2.12A7.22,7.22,0,0,1,15.5,7.88a7.23,7.23,0,0,1-2.12,5.34A7.23,7.23,0,0,1,8.11,15.5a7.21,7.21,0,0,1-5.33-2.12A7.24,7.24,0,0,1,.5,8.11,7.2,7.2,0,0,1,2.64,2.77,7.23,7.23,0,0,1,7.92.5Z"
                                            transform="translate(-0.5 -0.5)"></path>
                                        <path class="svg-foreground"
                                            d="M8,1.07a6.81,6.81,0,0,1,6.88,6.84A6.81,6.81,0,0,1,8,14.84H8A6.81,6.81,0,0,1,1.07,8,6.89,6.89,0,0,1,8,1.07H8M8.09.5h0A7.56,7.56,0,0,0,.5,8.09,7.38,7.38,0,0,0,8,15.5h.09A7.38,7.38,0,0,0,15.5,8,7.38,7.38,0,0,0,8.09.5Z"
                                            transform="translate(-0.5 -0.5)"></path>
                                        <path class="svg-foreground-invert"
                                            d="M6.9,12.55a2.84,2.84,0,0,0,1.3-.4A6.57,6.57,0,0,0,9.9,11l-.3-.4a2.38,2.38,0,0,1-1.1.6c-.1,0-.2-.2-.1-.6l.7-2.6c.3-1,.2-1.5-.4-1.5a3.36,3.36,0,0,0-1.4.5,5.67,5.67,0,0,0-1.8,1.2l.3.4A1.66,1.66,0,0,1,7,8c.1,0,.1.2,0,.5l-.6,2.4C6,12,6.2,12.55,6.9,12.55Z"
                                            transform="translate(-0.5 -0.5)"></path>
                                        <path class="svg-foreground-invert"
                                            d="M8.8,3a1.28,1.28,0,0,0-1,.4,1.23,1.23,0,0,0-.4.8,1.45,1.45,0,0,0,.2.7,1.14,1.14,0,0,0,.8.3,1.28,1.28,0,0,0,1-.4,1.27,1.27,0,0,0,.4-.9A.7.7,0,0,0,9.1,3Z"
                                            transform="translate(-0.5 -0.5)"></path>
                                    </svg></a>
                            </div>
                        </div>
                    </div>
                    <div class="qm-c-alert qm-c-alert--info" style="max-height: 600px; overflow: auto;"><span
                            class="qm-c-alert__icon"><img
                                src="data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PGRlZnM+PC9kZWZzPjx0aXRsZT5BbGVydC1JY29uczwvdGl0bGU+PHBhdGggZmlsbD0iIzMzMzMzMyIgZD0iTTEwLjgxLDE5LjA5YTQuMjMsNC4yMywwLDAsMCwxLjkzLS41OSw5Ljg5LDkuODksMCwwLDAsMi41My0xLjcxbC0uNDUtLjU5YTMuNjMsMy42MywwLDAsMS0xLjYzLjg5Yy0uMTUsMC0uMy0uMy0uMTUtLjg5bDEtMy44NmMuNDQtMS40OS4zLTIuMjMtLjYtMi4yM2E1LDUsMCwwLDAtMi4wNy43NCw4LjQ4LDguNDgsMCwwLDAtMi42OCwxLjc4bC40NS42QTIuNDMsMi40MywwLDAsMSwxMSwxMi4zNGMuMTUsMCwuMTUuMjksMCwuNzRsLS44OSwzLjU2QzkuNDgsMTguMjcsOS43NywxOS4wOSwxMC44MSwxOS4wOVoiLz48cGF0aCBmaWxsPSIjMzMzMzMzIiBkPSJNMTMuNjMsNC45MWExLjg5LDEuODksMCwwLDAtMS40OC42LDEuODUsMS44NSwwLDAsMC0uNiwxLjE4LDIuMiwyLjIsMCwwLDAsLjMsMUExLjY5LDEuNjksMCwwLDAsMTMsOC4xOGExLjg4LDEuODgsMCwwLDAsMS40OC0uNiwxLjg2LDEuODYsMCwwLDAsLjYtMS4zMywxLDEsMCwwLDAtMS0xLjM0WiIvPjxwYXRoIGZpbGw9IiMzMzMzMzMiIGQ9Ik0xMiwxLjA5QTEwLjkxLDEwLjkxLDAsMSwxLDEuMDksMTIsMTAuOTIsMTAuOTIsMCwwLDEsMTIsMS4wOU0xMiwwQTEyLDEyLDAsMSwwLDI0LDEyLDEyLDEyLDAsMCwwLDEyLDBaIi8+PC9zdmc+"
                                alt="Information"></span>
                        <div class="qm-c-alert__text">
                            <div class="updated_typography c-whats-new">
                                <h1>Settings Changed.</h1>
                                <p>The Boomi Platform Enhancer Extension options have been adjusted, please reload the page for the changes to apply.</p>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            <div class="button_set">
                <div class="button_spinner_panel no_display"> <i class="font_icon icon-spinner before-animate-spin spinner"></i> </div><button id="closeUpdate" type="button" class="gwt-Button">Close</button>
            </div>
        </div>
    </div>
    </div>`;
    let overlay = document.querySelector(".BoomiPlatformOverlay");
    if (overlay) overlay.remove();
    document.getElementsByTagName("body")[0].insertAdjacentHTML("beforeend", alert_html);
    updateFullscreenConfig();
  });

  // src/library/boomiapp/content/boomi.js
  var boomi_title = document.title;
  var boomiPageLoaded = setInterval(() => {
    if (boomi_title != document.title) {
      clearInterval(boomiPageLoaded);
      var subHeaderContainerNav = document.getElementsByClassName("qm-c-servicenav")[0];
      var headerAdd = document.getElementsByClassName(
        "qm-c-servicenav__navbar"
      )[0];
      if (headerAdd && subHeaderContainerNav.style.display != "none" && !subHeaderContainerNav.classList.contains("no_display")) {
        chrome.storage.local.get(["headerVisible"], function(e) {
          if (e.headerVisible == false) {
            document.getElementsByClassName("qm-c-masthead")[0].classList.add("headerHide");
          }
          var headerVisibilityState = !e.headerVisible && typeof e.headerVisible !== "undefined" ? "Show" : "Hide";
          $("#" + headerAdd.id).append(
            '<li id="showHeaderbtn" class="qm-c-servicenav__nav-item"><a class="gwt-Anchor qm-c-servicenav__nav-link qm-a--alternate"><span id="showHeaderspan" class="">' + headerVisibilityState + " Header</span></a></li>"
          );
        });
      }
      onNavigationChange();
      updateNotificationCheck();
    }
  }, 250);
  function onNavigationChange() {
    var urlPath = getUrlpath();
    chrome.storage.sync.get(["unique_titles_and_favicons"], function(e) {
      if (e.unique_titles_and_favicons == "on") {
        removeAccountPrefixFromDocumentTitle();
        changeFaviconBasedOnPage();
      }
    });
  }
  changeFaviconImage(
    "https://boomi.com/wp-content/uploads/Boomi_Logo_Icon_Navy.png"
  );
  window.addEventListener("popstate", onNavigationChange);
  window.addEventListener("onhashchange", onNavigationChange);
  document.addEventListener("visibilitychange", (event) => {
    if (document.visibilityState != "visible") {
      onNavigationChange();
    }
  });
  function removeAccountPrefixFromDocumentTitle() {
    setTimeout(function() {
      var title = document.title.replace(
        document.getElementsByClassName(
          "qm-c-inlinemenu__settings-menu-item-name"
        )[1].innerHTML,
        ""
      ).replace(/^(\s-\s)/, "");
      document.title = title;
    }, 250);
  }
  function changeFaviconBasedOnPage() {
    var subdomain = window.location.host.split(".")[0];
    var pageName = getPageNameWithoutExtension();
    var gwtPage = getGWTPageName();
    var svgIcon = "";
    switch (subdomain) {
      case "platform":
        switch (pageName) {
          case "AtomSphere":
            switch (gwtPage) {
              case "atom":
                svgIcon = "%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 194.24 194.23'%3E%3Cg id='Layer_2' data-name='Layer 2'%3E%3Cg id='Layer_1-2' data-name='Layer 1'%3E%3Cg id='AtomSphere_Platform_Coral' data-name='AtomSphere Platform Coral'%3E%3Cg class='cls-2'%3E%3Cg class='cls-3' fill='%23023d58'%3E%3Cpath class='cls-4' d='M132.31,97.12A35.19,35.19,0,1,1,97.12,61.93a35.2,35.2,0,0,1,35.19,35.19' transform='translate(0 0)'/%3E%3Cpath class='cls-4' d='M97.12,194.23a97.12,97.12,0,1,1,97.11-97.11,97.22,97.22,0,0,1-97.11,97.11m0-187.83a90.72,90.72,0,1,0,90.72,90.72A90.82,90.82,0,0,0,97.12,6.4' transform='translate(0 0)'/%3E%3Cpath class='cls-4' d='M174.78,42.08a16,16,0,1,1,0-22.62,16,16,0,0,1,0,22.62' transform='translate(0 0)'/%3E%3Cpath class='cls-4' d='M42.08,19.46a16,16,0,1,1-22.63,0,16,16,0,0,1,22.63,0' transform='translate(0 0)'/%3E%3Cpath class='cls-4' d='M19.46,152.15a16,16,0,1,1,0,22.63,16,16,0,0,1,0-22.63' transform='translate(0 0)'/%3E%3Cpath class='cls-4' d='M152.15,174.78a16,16,0,1,1,22.63,0,16,16,0,0,1-22.63,0' transform='translate(0 0)'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E";
                break;
              default:
                svgIcon = "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 204.28 204.28'%3E%3Cdefs%3E%3Cstyle%3E.cls-1 %7B fill: %23033d58; %7D%3C/style%3E%3C/defs%3E%3Cg id='Layer_2' data-name='Layer 2'%3E%3Cg id='Layer_1-2' data-name='Layer 1'%3E%3Cpath class='cls-1' d='M102.14,0A102.14,102.14,0,1,0,204.28,102.14,102.14,102.14,0,0,0,102.14,0Zm0,181.58v-22.7a56.74,56.74,0,0,1,0-113.48V22.7a79.44,79.44,0,0,1,0,158.88Z'%3E%3C/path%3E%3Cpath class='cls-1' d='M157.91,102.14a55.77,55.77,0,0,0-55.77-55.77V157.91A55.77,55.77,0,0,0,157.91,102.14Z'%3E%3C/path%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A";
                break;
            }
            break;
          case "MdmSphere":
            svgIcon = "%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 202.05 202.05'%3E%3Cdefs%3E%3CclipPath id='clip-path' transform='translate(0 0)'%3E%3Crect class='cls-1' width='202.05' height='202.05'%3E%3C/rect%3E%3C/clipPath%3E%3C/defs%3E%3Cg id='Layer_2' data-name='Layer 2'%3E%3Cg id='Layer_1-2' data-name='Layer 1'%3E%3Cg id='Master_Data_Hub_Navy' data-name='Master Data Hub Navy'%3E%3Cg class='cls-2'%3E%3Cg class='cls-2'%3E%3Cpath class='cls-3' d='M82.36,68.62,63.61,101,82.28,133.4l37.41,0,18.74-32.37L119.77,68.65ZM101,0a101,101,0,1,0,101,101A101,101,0,0,0,101,0m56.86,112.25,0,.06-18.7,32.31,10.42,18a78.18,78.18,0,0,1-19.43,11.26l-10.41-18.05h-.07l-37.33,0L71.89,173.93a77.94,77.94,0,0,1-19.42-11.26l10.4-18,0-.07L44.2,112.25H23.35a77.1,77.1,0,0,1-.9-11.23,77,77,0,0,1,.9-11.22h20.8l0-.06L62.9,57.43,52.47,39.37A78.56,78.56,0,0,1,71.89,28.11L82.31,46.17h.07l37.34,0,10.43-18.09a78.81,78.81,0,0,1,19.43,11.26l-10.4,18,0,.07L157.86,89.8H178.7a78.38,78.38,0,0,1,.9,11.22,78.52,78.52,0,0,1-.9,11.23Z' transform='translate(0 0)' fill='%23023d58'%3E%3C/path%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A";
            break;
          case "ApiSphere":
            svgIcon = "%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 189.77 189.77'%3E%3Cdefs%3E%3CclipPath id='clip-path' transform='translate(0 0)'%3E%3Crect class='cls-1' width='189.77' height='189.77'%3E%3C/rect%3E%3C/clipPath%3E%3C/defs%3E%3Cg id='Layer_2' data-name='Layer 2'%3E%3Cg id='Layer_1-2' data-name='Layer 1'%3E%3Cg id='API_Management_Navy' data-name='API Management Navy'%3E%3Cg class='cls-2'%3E%3Cg class='cls-2'%3E%3Cpath class='cls-3' d='M94.89,0a94.88,94.88,0,1,0,94.88,94.88A94.88,94.88,0,0,0,94.89,0M84.35,65.84,64.48,77.29l0,35.12,19.91,11.53v24.35l-.06,0-40.95-23.7.07-59.48L84.35,41.51Zm62,58.85-40.93,23.57V123.93l19.85-11.44,0-35.14L105.43,65.83V41.46l0,0,40.94,23.69Z' transform='translate(0 0)' fill='%23023d58'%3E%3C/path%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A";
            break;
        }
        break;
      case "flow":
        svgIcon = "%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 202.05 202.05'%3E%3Cdefs%3E%3CclipPath id='clip-path' transform='translate(-0.01 0)'%3E%3Crect class='cls-1' width='202.05' height='202.05'%3E%3C/rect%3E%3C/clipPath%3E%3C/defs%3E%3Cg id='Layer_2' data-name='Layer 2'%3E%3Cg id='Layer_1-2' data-name='Layer 1'%3E%3Cg id='Flow_Navy' data-name='Flow Navy'%3E%3Cg class='cls-2'%3E%3Cg class='cls-2'%3E%3Cpath class='cls-3' d='M101,0a101,101,0,1,0,101,101A101,101,0,0,0,101,0M179.6,101a78.15,78.15,0,0,1-.9,11.22H137.48l-44.9,44.9H46.14a78.78,78.78,0,0,1-16-22.45H83.27l44.9-44.9H178.7a78.64,78.64,0,0,1,.9,11.23M100.23,22.49,55.38,67.35H30.13a78.64,78.64,0,0,1,70.1-44.86M23.34,89.79H64.67l44.9-44.89h46.35a79.22,79.22,0,0,1,16,22.45h-53L74,112.24H23.34a72,72,0,0,1,0-22.45m78.58,89.76,44.85-44.86H171.9a78.56,78.56,0,0,1-70,44.86' transform='translate(-0.01 0)' fill='%23023d58'%3E%3C/path%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A";
        break;
    }
    if (svgIcon) {
      changeFaviconToSVG(svgIcon);
    }
  }
  function changeFaviconToSVG(svgIcon) {
    iconHrefData = "data:image/svg+xml, " + svgIcon;
    changeFaviconImage(iconHrefData);
  }
  function changeFaviconImage(link) {
    var faviconIcon = document.getElementsByTagName("head")[0].querySelector("link[rel~='icon']") || document.getElementsByTagName("head")[0].querySelector("link[rel='shortcut icon']");
    if (!faviconIcon) {
      faviconIcon = document.createElement("link");
      faviconIcon.rel = "icon";
      document.getElementsByTagName("head")[0].appendChild(faviconIcon);
    }
    if (faviconIcon) {
      faviconIcon.href = link;
    }
  }

  // src/library/boomiapp/content/clickComponents.js
  $(document).ready(function() {
    $(document).on("click", "#showHeaderbtn", function() {
      var x = document.getElementsByClassName("qm-c-masthead");
      chrome.storage.local.get(["headerVisible"], function(e) {
        var headerVisible = e.headerVisible;
        if (typeof headerVisible == "undefined") {
          headerVisible = true;
        }
        if (headerVisible == true) {
          x[0].classList.add("headerHide");
          $("#showHeaderspan").text("Show Header");
          headerVisible = false;
        } else {
          x[0].classList.remove("headerHide");
          $("#showHeaderspan").text("Hide Header");
          headerVisible = true;
        }
        chrome.storage.local.set({ headerVisible }, function() {
        });
      });
    });
    $(document).on("click", "#gwt-uid-84", function() {
      dashboardDays();
    });
    document.arrive(
      '[data-locator="link-enter-full-screen"]',
      function(element) {
        var ul = $(element).closest("ul")[0];
        $(ul).append(
          '<li id="copyCompID"><a class="gwt-Anchor">Copy Current Component ID</a></li>'
        );
        $(ul).append(
          '<li id="copyCompURL"><a class="gwt-Anchor">Copy Current Component URL</a></li>'
        );
      }
    );
    $(document).on("click", "#copyCompID", function() {
      var currentId = getUrlParameter("componentIdOnFocus");
      $("#mastfoot").append(
        '<input type="text" value="' + currentId + '" id="currentidval">'
      );
      var currentidval = document.getElementById("currentidval");
      currentidval.select();
      currentidval.setSelectionRange(0, 99999);
      document.execCommand("copy");
      $("#currentidval").remove();
      showInformationAlertDialog(
        "Current ID " + currentId + " Copied to Clipboard."
      );
      return false;
    });
    $(document).on("click", "#copyCompURL", function() {
      var currentId = getUrlParameter("componentIdOnFocus");
      var accountId = getUrlParameter("accountId") || document.querySelector('[data-locator="link-process-reporting"]').href.split("=").pop().split(";")[0];
      $("#mastfoot").append(
        '<input type="text" value="https://platform.boomi.com/AtomSphere.html#build;accountId=' + accountId + ";components=" + currentId + '" id="currenturlval">'
      );
      var currentidval = document.getElementById("currenturlval");
      currentidval.select();
      currentidval.setSelectionRange(0, 99999);
      document.execCommand("copy");
      $("#currenturlval").remove();
      showInformationAlertDialog(
        "Current Component URL Copied to Clipboard. (" + currentId + ")"
      );
      return false;
    });
    $(document).on("click", "#closeUpdate", function() {
      $(".BoomiUpdateOverlay").remove();
    });
  });

  // src/library/boomiapp/content/dashboard.js
  $(document).ready(function() {
    dashboardDays();
    window.onhashchange = function() {
      var dashboardCheck = getUrlpath();
      var vali = dashboardCheck.includes("dashboard");
      if (vali == true) {
        dashboardDays();
      }
    };
  });

  // src/library/boomiapp/content/buildPallet.js
  var psc = 0;
  var DefaultPaletteWidth = 250;
  function GM_addStyle(cssStr) {
    var targ = document.getElementsByTagName("head")[0] || D.body || D.documentElement;
    var st = document.createElement("style");
    st.textContent = cssStr;
    targ.appendChild(st);
  }
  GM_addStyle(`
    .base_shape_container div{padding: 3px !important;}
    .qm-l-auto-fill-grid {grid-gap: 3px !important;}
    .palette_shape_container_with_hover { border: none !important; }
`);
  function DisplayPalette(toggle, el) {
    el.children[0].children[1].style.display = toggle ? "none" : "";
    el.children[0].children[1].style.left = toggle ? "-100%" : "0%";
    el.children[0].children[1].children[0].style.display = toggle ? "none" : "";
    el.children[0].children[2].style.display = toggle ? "" : "none";
    el.children[0].children[2].style.left = toggle ? "0%" : "100%";
    el.children[0].children[2].children[0].style.display = toggle ? "" : "none";
    el.attributes["ExpandButton"].disabled = toggle;
    el.attributes["CloseButton"].disabled = !toggle;
  }
  function ExpandPalette(toggle, el) {
    var width = toggle ? el.attributes["PaletteWidth"] : 44;
    if (!toggle) el.attributes["PaletteWidth"] = el.clientWidth;
    el.attributes["ShapePaletteParent"].style.width = width + "px";
    el.attributes["CollapsibleDragger"].style.left = width + "px";
    el.attributes["BuildCanvas"].style.inset = "0px 0px 0px " + (width + 12) + "px";
    el.style.width = width + "px";
  }
  function InitCollapsiblePanel(p) {
    var el = p.children[1];
    var cdp = p.children[2];
    var cd = cdp.children[0];
    var ebt = cd.children[0];
    var cbt = cd.children[2];
    el.attributes["PaletteWidth"] = DefaultPaletteWidth;
    el.attributes["ShapePaletteParent"] = el.children[0];
    el.attributes["CollapsibleDragger"] = cdp;
    el.attributes["BuildCanvas"] = p.children[3];
    el.attributes["ExpandButton"] = ebt;
    el.attributes["CloseButton"] = cbt;
    ebt.onclick = function() {
      ExpandPalette(true, el);
    };
    cbt.onclick = function() {
      ExpandPalette(false, el);
    };
    cd.ondblclick = function() {
      ExpandPalette(cbt.disabled, el);
    };
    return el;
  }
  var resizeObserver = new ResizeObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.contentRect.width == 700) {
        console.log("Old Shape Palette Expand Detected");
        ExpandPalette(true, entry.target);
      } else DisplayPalette(entry.contentRect.width > 44, entry.target);
    });
  });
  var docObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (!mutation.addedNodes) return;
      var ps = document.getElementsByClassName("collapsible_base_panel");
      if (ps && ps.length != psc) {
        psc = ps.length;
        for (var i = 1; i < ps.length; i++) {
          if (!ps[i].attributes["sizeobserved"]) {
            resizeObserver.observe(InitCollapsiblePanel(ps[i]));
            ps[i].attributes["sizeobserved"] = true;
          }
        }
      }
    });
  });
  docObserver.observe(document, {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false
  });

  // src/library/boomiapp/content/shortCuts.js
  $(document).ready(function() {
    shortcut.add("Alt+Ctrl+S", function() {
      var x = document.querySelectorAll('[data-locator="button-save"]');
      $(x).each(function() {
        if ($(this).is(":visible")) {
          $(this).click();
        }
      });
    });
    shortcut.add("Alt+Ctrl+T", function() {
      var x = document.querySelectorAll('[data-locator="button-test"]');
      $(x).each(function() {
        if ($(this).is(":visible")) {
          $(this).click();
        }
      });
    });
  });

  // src/library/boomiapp/content/messageEditor.js
  var langs = {
    plain_text: { mode: "default", display: "Plain Text" },
    json: { mode: { name: "javascript", json: true }, display: "JSON" },
    xml: { mode: "xml", display: "XML" },
    html: { mode: { name: "xml", html: true }, display: "HTML" },
    sql: { mode: "sql", display: "SQL" }
  };
  document.arrive(
    '.gwt-TextArea.validatable[data-locator="formrow-message"]',
    function() {
      var bpeButtonId = `#bpe-message-editor-button-${this.id}`;
      $(this).parent().append(
        `<button type="button" class="gwt-Button qm-button--primary-action" id="bpe-message-editor-button-${this.id}" textareaid="${this.id}"style="display: block">Edit Message</button>`
      );
      $(bpeButtonId).click(function(e) {
        let textAreaId = `#${e.target.getAttribute("textareaid")}`;
        $("body").append(renderMessageEditorPopup(this.id));
        var code2 = $(textAreaId)[0].value.replace(/^'*/, "").replace(/'*$/, "").replace(/'({\d+})'/g, "$1");
        editor = CodeMirror($("#bpe-message-editor")[0], {
          value: code2,
          mode: "default",
          lineNumbers: true,
          autoCloseTags: true,
          autoCloseBrackets: true
        });
        switch (code2.charAt(0)) {
          case "{":
            editor.setOption("mode", langs["json"].mode);
            $("#bpe-message-editor-language")[0].value = "json";
            break;
          case "[":
            editor.setOption("mode", langs["json"].mode);
            $("#bpe-message-editor-language")[0].value = "json";
            break;
          case "<":
            if (code2.includes("<html>")) {
              editor.setOption("mode", langs["html"].mode);
              $("#bpe-message-editor-language")[0].value = "html";
              break;
            }
            editor.setOption("mode", langs["xml"].mode);
            $("#bpe-message-editor-language")[0].value = "xml";
            break;
        }
        var theme = $("html").hasClass("qm-u-theme-dark") ? "twilight" : "default";
        editor.setOption("theme", theme);
        $("#bpe-message-editor-ok").click(function() {
          let lang = $("#bpe-message-editor-language")[0].value;
          let code3 = editor.getValue();
          switch (lang) {
            case "json":
              if (code3 == null ? void 0 : code3.trim())
                code3 = code3.trim().replace(/^'*/, "'").replace(/'*$/, "'").replace(/'*({\d+})'*/g, "'$1'");
              break;
          }
          $(textAreaId)[0].value = code3;
          $("#popup_on_popup_content, #popup_on_popup").remove();
        });
        $("#bpe-message-editor-cancel").click(function() {
          $("#popup_on_popup_content, #popup_on_popup").remove();
        });
        $("#bpe-message-editor-language").change(function(e2) {
          editor.setOption("mode", langs[e2.target.value].mode);
        });
      });
    }
  );
  document.arrive(
    '.gwt-TextArea.validatable[data-locator="formrow-sql"]',
    function() {
      var progShape = $(this).closest(".prog_cmd_panel");
      if (progShape.length === 0) return;
      var bpeButtonId = `#bpe-sql-editor-button-${this.id}`;
      $(progShape).find(`button[data-locator="button-edit-sql"]`).parent().remove();
      $(this).parent().append(
        `<button type="button" class="gwt-Button qm-button--primary-action" id="bpe-sql-editor-button-${this.id}" textareaid="${this.id}"style="display: block">Edit SQL</button>`
      );
      $(bpeButtonId).click(function(e) {
        let textAreaId = `#${e.target.getAttribute("textareaid")}`;
        $("body").append(renderMessageEditorPopup(this.id, "sql"));
        var code2 = $(textAreaId)[0].value;
        editor = CodeMirror($("#bpe-message-editor")[0], {
          value: code2,
          mode: "sql",
          lineNumbers: true,
          autoCloseTags: true,
          autoCloseBrackets: true
        });
        var theme = $("html").hasClass("qm-u-theme-dark") ? "twilight" : "default";
        editor.setOption("theme", theme);
        $("#bpe-message-editor-ok").click(function() {
          let code3 = editor.getValue();
          $(textAreaId)[0].value = code3;
          $("#popup_on_popup_content, #popup_on_popup").remove();
        });
        $("#bpe-message-editor-cancel").click(function() {
          $("#popup_on_popup_content, #popup_on_popup").remove();
        });
        $("#bpe-message-editor-language").change(function(e2) {
          editor.setOption("mode", langs[e2.target.value].mode);
        });
      });
    }
  );
  function renderMessageEditorPopup(id, lang) {
    let left = Math.abs(window.innerWidth / 2) - 600;
    let top = Math.abs(window.innerHeight / 2) - 340;
    let lang_html = "";
    let title = "Edit Message";
    if (!lang) {
      for (const [k2, v] of Object.entries(langs)) {
        lang_html += `<option value="${k2}">${v.display}</option>`;
      }
    } else {
      title = `Edit ${lang.toUpperCase()}`;
      lang_html = `<option value="${langs[lang]}">${langs[lang].display}</option>`;
    }
    let html = `
    <div class="popup_on_popup" id="popup_on_popup" style="position: absolute; left: 0px; top: 0px; visibility: visible; display: block; width: 100%; height: 100%;"></div>
    <div class="center_panel" id="popup_on_popup_content" role="dialog" aria-modal="true" style="left: ${left}px; top: ${top}px; visibility: visible; position: absolute; overflow: visible;">
        <div class="popupContent">
            <div class="modal modal_top"> 
                <div class="modal_contents">
                    <div class="flex_panel" style="width: 1200px; height: 600px;">
                        <div class="form_header inline_script_editor_header" style="flex:0 0 auto;">
                            <div class="form_title no_required">
                                <div class="form_title_top">
                                    <h2 class="form_title_label">${title}</h2>
                                </div>
                                <dl class="property_list no_display"></dl>
                                <p class="form_summary no_display"></p>
                            </div>
                        </div>
                        <div class="inline_script_editor_settings_row" style="flex:0 0 auto;">
                            <div class="inline_script_editor_language_list">
                                <div class="form_row">
                                    <div class="form_label">
                                        <label for="bpe-message-editor-language">Language
                                            <span class="form_label_required">*</span>
                                        </label> 
                                        <span class="form_label_required_text">(required)</span>
                                    </div>
                                    <div class="validation_panel">
                                        <div class="container">
                                            <select class="gwt-ListBox validatable" id="bpe-message-editor-language">
                                                ${lang_html}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="flex:1 1 0%;">
                            <div style="height: 100%; position: absolute; width: 100%;">
                                <div class="collapsible_base_panel" style="position: relative;">
                                    <div aria-hidden="true" style="position: absolute; z-index: -32767; top: -20ex; width: 10em; height: 10ex; visibility: hidden;">&nbsp;</div>
                                    <div style="position: absolute; inset: 0px;">
                                        <div id="bpe-message-editor" style="position: absolute; inset: 0px;">
                                            <!-- MESSAGE EDITOR GOES HERE -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="button_set left">
                    <button type="button" class="gwt-Button qm-button--primary-action" id="bpe-message-editor-ok" parent-id="${id}" >OK</button>
                    <button type="button" class="gwt-Button" id="bpe-message-editor-cancel">Cancel</button>
                </div>
            </div>
        </div>
    </div>`;
    return html;
  }

  // src/library/boomiapp/content/reminders.js
  document.arrive(
    "[data-locator='button-view-deployments']",
    function(deploymentScreen) {
      chrome.storage.sync.get(["reminder_schedule"], function(e) {
        if (e.reminder_schedule === "on") {
          let scheduleHtml = `
    <p><b style="color: orange">REMINDER:</b> Dont forget to set up a schedule in the runtime if its required for your deployed service</p>`;
          deploymentScreen.offsetParent.parentNode.firstChild.firstChild.children[1].insertAdjacentHTML(
            "afterend",
            scheduleHtml
          );
        }
      });
    }
  );

  // src/library/boomiapp/content/buildFilters.js
  document.arrive(".filter_popup", function(filteredScreen) {
    var processFilter;
    var processPropFilter;
    var CrossFilter;
    chrome.storage.sync.get(["Filter_process"], function(e) {
      processFilter = e.Filter_process;
    });
    chrome.storage.sync.get(["Filter_processProp"], function(e) {
      processPropFilter = e.Filter_processProp;
    });
    chrome.storage.sync.get(["Filter_crossref"], function(e) {
      CrossFilter = e.Filter_crossref;
    });
    chrome.storage.sync.get(["Filter_api_service"], function(e) {
      APIServFilter = e.Filter_api_service;
    });
    chrome.storage.sync.get(["apply_process_filters"], function(e) {
      if (e.apply_process_filters === "on") {
        var matchingxref = document.evaluate(
          "//label[contains(text(),'Cross Reference Table')]",
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        var matchingprocess = document.evaluate(
          "//label[contains(text(),'Process')]",
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        var matchingproprop = document.evaluate(
          "//label[contains(text(),'Process Property')]",
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        var matchingapiserv = document.evaluate(
          "//label[contains(text(),'API Service')]",
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        ).singleNodeValue;
        document.getElementById(matchingprocess.htmlFor).checked = processFilter;
        document.getElementById(matchingproprop.htmlFor).checked = processPropFilter;
        document.getElementById(matchingxref.htmlFor).checked = CrossFilter;
        document.getElementById(matchingapiserv.htmlFor).checked = APIServFilter;
      }
    });
  });

  // src/library/boomiapp/content/filterButtons.js
  document.arrive(".filter_panel_dialog_popup_panel", function(filterpanel) {
    if (filterpanel.querySelector(".filterable_tree_loading_container")) {
      var buttonBar = document.getElementsByClassName("button-bar");
      buttonBar[0].insertAdjacentHTML(
        "beforeend",
        '<button id="collapseFolders" type="button" class="gwt-Button">Collapse All Folders</button>'
      );
    }
  });
  $(document).on("click", "#collapseFolders", function() {
    [
      ...document.getElementsByClassName("filter_panel_dialog_popup_panel")[0].querySelectorAll(".open")
    ].reverse().forEach((element) => {
      closeNode(element);
    });
    function closeNode(targetNode) {
      ["mouseover", "mousedown", "mouseup"].forEach(function(eventType) {
        var clickEvent = document.createEvent("MouseEvents");
        clickEvent.initEvent(eventType, true, true);
        targetNode.dispatchEvent(clickEvent);
      });
    }
  });
  document.arrive("[data-locator='button-schedules']", function(schedulebutton) {
    schedulebutton.parentNode.insertAdjacentHTML(
      "beforeend",
      '<button type="button" id="collapseDeployedFolders" class="gwt-Button drop_button qm-button--primary-action closeall_doing_action" style="position: absolute">Collapse All Folders</button>'
    );
  });
  document.arrive(".rail.simplify .gwt-FastTree .treeItemContent", function(el) {
    if (!el.onclick) {
      el.onclick = function(e) {
        if (this.parentElement.parentElement.classList.contains("children")) {
          doubleClickNode(e.target);
          return;
        }
        clickNode(
          this.parentElement.parentElement.querySelector(".closed,.open")
        );
      };
    }
    function clickNode(targetNode) {
      ["mouseover", "mousedown", "mouseup"].forEach(function(eventType) {
        var clickEvent = document.createEvent("MouseEvents");
        clickEvent.initEvent(eventType, true, true);
        targetNode.dispatchEvent(clickEvent);
      });
    }
    function doubleClickNode(targetNode) {
      var clickEvent = document.createEvent("MouseEvents");
      clickEvent.initEvent("dblclick", true, true);
      targetNode.dispatchEvent(clickEvent);
    }
  });
  $(document).on("click", "#collapseDeployedFolders", function() {
    [
      ...document.getElementsByClassName("deployed_processes_panel")[0].querySelectorAll(".open")
    ].reverse().forEach((element) => {
      closeNode(element);
    });
    function closeNode(targetNode) {
      ["mouseover", "mousedown", "mouseup"].forEach(function(eventType) {
        var clickEvent = document.createEvent("MouseEvents");
        clickEvent.initEvent(eventType, true, true);
        targetNode.dispatchEvent(clickEvent);
      });
    }
  });

  // src/library/boomiapp/content/quickclickComponent.js
  document.arrive(".gwt-ProcessPanel", function(panel) {
    $(panel).on("mousedown", function(e) {
      e.preventDefault();
      $(".bpe-quickshape-popup").each(function() {
        $(this).remove();
      });
    });
    $(panel).on("dblclick", function(e) {
      e.preventDefault();
      if (!$(".copy_paste_panel").hasClass("no_display") || !Array.from(document.querySelectorAll(".testModeCover")).every(
        (el) => el.offsetParent === null
      ) || typeof window.getSelection != "undefined" && window.getSelection().toString() !== "") {
        return;
      }
      $(".bpe-quickshape-popup").each(function() {
        $(this).remove();
      });
      rendorQuickShapePopup(panel, e.offsetX, e.offsetY, e.clientX, e.clientY);
    });
  });
  function rendorQuickShapePopup(obj, offsetX, offsetY, clientX, clientY) {
    quick_shape_added = { added: false, clientX: 0, clientY: 0 };
    var shapes_array = {};
    var shapes_array_html = "";
    $(".gwt-Label.base_shape_container_label").each(function() {
      shapes_array[this.innerHTML] = $(this).parent().children().find("img").attr("src");
    });
    shapes_array_sorted = Object.keys(shapes_array).sort().reduce((accumulator, key) => {
      accumulator[key] = shapes_array[key];
      return accumulator;
    }, {});
    Object.entries(shapes_array_sorted).forEach((shape) => {
      let div = ` <div tabindex="0" class="category_row_hover_style bpe-quickshape-shape" data-locator="${shape[0]}">
                        <input type="text" tabindex="-1" role="presentation" style="opacity: 0; height: 1px; width: 1px; z-index: -1; overflow: hidden; position: absolute;">
                        <div class="category_row_style">
                            <div class="left_style">
                                <img src="${shape[1]}" class="gwt-Image" title="${shape[0]}" style="width: 20px; height: 20px;">
                            </div>
                            <div class="right_style">
                                <div class="gwt-Label">${shape[0]}</div>
                            </div>
                        </div>
                    </div>`;
      shapes_array_html += div;
    });
    let html = `<div class="category_listbox_chooser_popup new_shape_chooser_popup bpe-quickshape-popup" style="top:${offsetY}px;left:${offsetX}px; overflow: visible; visibility: visible; position: absolute;">
                    <div class="popupContent">
                        <div>
                            <div class="filter_widget">
                                <div class="text_search_box">
                                    <input type="text" class="filter_search_input" id="bpe-quickshape-input" placeholder="What type of shape do you want to create?"> 
                                    <i class="input_icon icon-search"></i>
                                </div> 
                                <i class="font_icon icon-arrows-cw filter_refresh" data-locator="icon-arrows-cw"></i>
                            </div>
                            <div class="gwt-Label empty_label_style no_display">There is no data to display.</div>
                            <div class="component_list">
                                ${shapes_array_html}
                            </div>
                        </div>
                    </div>
                </div>`;
    $(obj).append(html);
    $("#bpe-quickshape-input").focus();
    $("#bpe-quickshape-input").keyup(function(e) {
      var filter = this.value.toLowerCase();
      if (e.key === "Escape") {
        $(".bpe-quickshape-popup").each(function() {
          $(this).remove();
        });
        return;
      } else {
        if (e.key === "Enter") {
          if (filter == null ? void 0 : filter.trim()) {
            var option = $(".component_list").find(".bpe-quickshape-shape").not(".no_display")[0];
            if (option !== void 0) {
              var shape = $(this).closest(".component_editor_panel").find(
                `.gwt-Label.base_shape_container_label:contains('${$(option).attr("data-locator")}')`
              )[0];
              shape.parentElement.parentElement.dispatchEvent(
                new MouseEvent("mousedown")
              );
              obj.dispatchEvent(
                new MouseEvent("mouseup", { clientX, clientY })
              );
            }
          }
          $(".bpe-quickshape-popup").each(function() {
            $(this).remove();
          });
          return;
        }
      }
      $(".bpe-quickshape-shape").each(function() {
        shape = $(this);
        if (shape.attr("data-locator").toLowerCase().indexOf(filter) > -1) {
          shape.removeClass("no_display");
        } else {
          shape.addClass("no_display");
        }
      });
    });
    $(".bpe-quickshape-shape").on("mousedown", function(e) {
      e.stopPropagation();
      e.stopImmediatePropagation();
      var shape = $(this).closest(".component_editor_panel").find(
        `.gwt-Label.base_shape_container_label:contains('${$(this).attr("data-locator")}')`
      )[0];
      shape.parentElement.parentElement.dispatchEvent(
        new MouseEvent("mousedown")
      );
      obj.dispatchEvent(
        new MouseEvent("mouseup", { clientX, clientY })
      );
      $(".bpe-quickshape-popup").each(function() {
        $(this).remove();
      });
    });
  }

  // src/library/boomiapp/content/menuOpen.js
  document.arrive(".qm-c-servicenav", function(nav) {
    $(nav).find(".qm-c-inlinemenu__menu-link").each(function() {
      var anchor = $(this);
      var parent = anchor.parent();
      var desc = this.innerHTML;
      var href = anchor.attr("href");
      parent.addClass("qm-c-inlinemenu__descriptive-composite-menu-item");
      anchor.removeClass("qm-c-inlinemenu__menu-link").addClass("qm-c-inlinemenu__descriptive-composite-menu-link");
      this.innerHTML = `<p class="qm-c-inlinemenu__descriptive-composite-menu-detail">${desc}</p>`;
      anchor.css("width", "14em");
      parent.append(`<a class="gwt-Anchor svg-anchor qm-c-inlinemenu__descriptive-composite-menu-icon" href="${href}" target="_blank">
                    <svg xmlns=http://www.w3.org/2000/svg viewBox="0 0 32 32" width="32" height="32" style="width: 16px; height: 16px;">
                      <title>Open in new tab.</title>
                      <path class="svg-foreground" d="M18.7273 3.99994C18.7274 3.39745 19.2159 2.9091 19.8183 2.90918L27.9991 2.91027C28.6015 2.91035 29.0898 3.39866 29.0898 4.00103L29.0909 12.1818C29.091 12.7843 28.6027 13.2727 28.0002 13.2728C27.3977 13.2729 26.9092 12.7845 26.9091 12.1821L26.9082 5.09194L19.8181 5.091C19.2156 5.09092 18.7272 4.60244 18.7273 3.99994Z"></path>
                      <path class="svg-foreground" d="M28.7676 3.23261C29.1937 3.65863 29.1937 4.34936 28.7676 4.77538L18.9495 14.5936C18.5234 15.0196 17.8327 15.0196 17.4067 14.5936C16.9807 14.1675 16.9807 13.4768 17.4067 13.0508L27.2249 3.23261C27.6509 2.80658 28.3416 2.80658 28.7676 3.23261Z"></path>
                      <path class="svg-foreground" d="M3.54822 7.91175C3.95739 7.50258 4.51234 7.27271 5.091 7.27271H13.8183C14.4208 7.27271 14.9092 7.76112 14.9092 8.36361C14.9092 8.96611 14.4208 9.45452 13.8183 9.45452L5.091 9.45452L5.091 26.9091H22.5455V18.1818C22.5455 17.5793 23.034 17.0909 23.6365 17.0909C24.2389 17.0909 24.7274 17.5793 24.7274 18.1818V26.9091C24.7274 27.4877 24.4975 28.0427 24.0883 28.4518C23.6791 28.861 23.1242 29.0909 22.5455 29.0909H5.091C4.51235 29.0909 3.95739 28.861 3.54822 28.4518C3.13905 28.0427 2.90918 27.4877 2.90918 26.9091V9.45452C2.90918 8.87587 3.13905 8.32091 3.54822 7.91175Z"></path>
                    </svg>
                  </a>`);
    });
    document.unbindArrive(".qm-c-servicenav");
  });

  // src/library/boomiapp/content/scheduleIcons.js
  document.arrive(".deployed_processes_panel", function(processPanel) {
    chrome.storage.sync.get(["schedule_icon"], function(e) {
      if (e.schedule_icon === "on") {
        setInterval(function() {
          var images = document.querySelectorAll(
            '[class*="deployed_processes_panel"] .gwt-Image'
          );
          for (var index = 0; index < images.length; index++) {
            if (images[index].src.includes("process-running")) {
              onSrcChange(images[index]);
            } else if (images[index].src.includes("process-pause")) {
              onSrcChangePause(images[index]);
            }
          }
        }, 1e3);
      }
    });
  });
  function onSrcChange(imgChange) {
    imgChange.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4IiB2aWV3Qm94PSIwIDAgMTYgMTYiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgc3R5bGU9ImJhY2tncm91bmQ6ICNGRkZGRkY7Ij4KICAgIDx0aXRsZT5wcm9jZXNzIHJ1bm5pbmc8L3RpdGxlPgogICAgPGcgaWQ9InByb2Nlc3MtcnVubmluZyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPHJlY3QgZmlsbD0iI0ZGRkZGRiIgeD0iMCIgeT0iMCIgd2lkdGg9IjE2IiBoZWlnaHQ9IjE2Ij48L3JlY3Q+CiAgICAgICAgPGcgaWQ9InByb2Nlc3MiIG9wYWNpdHk9IjAuNTk2MTIxNjUyIiBmaWxsPSIjNzU3NTc1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPgogICAgICAgICAgICA8cGF0aCBkPSJNOC40MjM1ODUzNSwxMi43NzQyOTI3IEw3LDEyLjA2MjUgTDcsMTAuOTM3NSBMOC40MjM1ODUzNSwxMC4yMjU3MDczIEw3LjkyMDI3MTkyLDguNzE1NzY3MDUgTDguNzE1NzY3MDUsNy45MjAyNzE5MiBMMTAuMjI1NzA3Myw4LjQyMzU4NTM1IEwxMC45Mzc1LDcgTDEyLjA2MjUsNyBMMTIuNzc0MjkyNyw4LjQyMzU4NTM1IEwxNC4yODQyMzMsNy45MjAyNzE5MiBMMTUuMDc5NzI4MSw4LjcxNTc2NzA1IEwxNC41NzY0MTQ3LDEwLjIyNTcwNzMgTDE2LDEwLjkzNzUgTDE2LDEyLjA2MjUgTDE0LjU3NjQxNDcsMTIuNzc0MjkyNyBMMTUuMDc5NzI4MSwxNC4yODQyMzMgTDE0LjI4NDIzMywxNS4wNzk3MjgxIEwxMi43NzQyOTI3LDE0LjU3NjQxNDcgTDEyLjA2MjUsMTYgTDEwLjkzNzUsMTYgTDEwLjIyNTcwNzMsMTQuNTc2NDE0NyBMOC43MTU3NjcwNSwxNS4wNzk3MjgxIEw3LjkyMDI3MTkyLDE0LjI4NDIzMyBMOC40MjM1ODUzNSwxMi43NzQyOTI3IFogTTEuNDIzNTg1MzUsNS43NzQyOTI2NyBMMCw1LjA2MjUgTDAsMy45Mzc1IEwxLjQyMzU4NTM1LDMuMjI1NzA3MzMgTDAuOTIwMjcxOTIsMS43MTU3NjcwNSBMMS43MTU3NjcwNSwwLjkyMDI3MTkyIEwzLjIyNTcwNzMzLDEuNDIzNTg1MzUgTDMuOTM3NSwwIEw1LjA2MjUsMCBMNS43NzQyOTI2NywxLjQyMzU4NTM1IEw3LjI4NDIzMjk1LDAuOTIwMjcxOTIgTDguMDc5NzI4MDgsMS43MTU3NjcwNSBMNy41NzY0MTQ2NSwzLjIyNTcwNzMzIEw5LDMuOTM3NSBMOSw1LjA2MjUgTDcuNTc2NDE0NjUsNS43NzQyOTI2NyBMOC4wNzk3MjgwOCw3LjI4NDIzMjk1IEw3LjI4NDIzMjk1LDguMDc5NzI4MDggTDUuNzc0MjkyNjcsNy41NzY0MTQ2NSBMNS4wNjI1LDkgTDMuOTM3NSw5IEwzLjIyNTcwNzMzLDcuNTc2NDE0NjUgTDEuNzE1NzY3MDUsOC4wNzk3MjgwOCBMMC45MjAyNzE5Miw3LjI4NDIzMjk1IEwxLjQyMzU4NTM1LDUuNzc0MjkyNjcgWiBNNC41LDYuMTg3NSBDNS40MzE5ODA1Miw2LjE4NzUgNi4xODc1LDUuNDMxOTgwNTIgNi4xODc1LDQuNSBDNi4xODc1LDMuNTY4MDE5NDggNS40MzE5ODA1MiwyLjgxMjUgNC41LDIuODEyNSBDMy41NjgwMTk0OCwyLjgxMjUgMi44MTI1LDMuNTY4MDE5NDggMi44MTI1LDQuNSBDMi44MTI1LDUuNDMxOTgwNTIgMy41NjgwMTk0OCw2LjE4NzUgNC41LDYuMTg3NSBaIE0xMS41LDEzLjE4NzUgQzEyLjQzMTk4MDUsMTMuMTg3NSAxMy4xODc1LDEyLjQzMTk4MDUgMTMuMTg3NSwxMS41IEMxMy4xODc1LDEwLjU2ODAxOTUgMTIuNDMxOTgwNSw5LjgxMjUgMTEuNSw5LjgxMjUgQzEwLjU2ODAxOTUsOS44MTI1IDkuODEyNSwxMC41NjgwMTk1IDkuODEyNSwxMS41IEM5LjgxMjUsMTIuNDMxOTgwNSAxMC41NjgwMTk1LDEzLjE4NzUgMTEuNSwxMy4xODc1IFoiIGlkPSJDb21iaW5lZC1TaGFwZSI+PC9wYXRoPgogICAgICAgIDwvZz4KICAgICAgICA8ZyBpZD0icnVubmluZyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNS4wMDAwMDAsIDMuMDAwMDAwKSIgZmlsbD0iIzZFQTIwNCIgc3Ryb2tlPSIjRkZGRkZGIj4KICAgICAgICAgICAgPHBhdGggZD0iTTIuMjA3MTA2NzgsLTAuNSBMLTAuNSwtMC41IEwtMC41LDEwLjUgTDIuMjA3MTA2NzgsMTAuNSBMNy43MDcxMDY3OCw1IEwyLjIwNzEwNjc4LC0wLjUgWiIgaWQ9IlJlY3RhbmdsZSI+PC9wYXRoPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+";
  }
  function onSrcChangePause(imgChange) {
    imgChange.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4IiB2aWV3Qm94PSIwIDAgMTYgMTYiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgc3R5bGU9ImJhY2tncm91bmQ6ICNGRkZGRkY7Ij4KICAgIDx0aXRsZT5wcm9jZXNzIHBhdXNlPC90aXRsZT4KICAgIDxnIGlkPSJwcm9jZXNzLXBhdXNlIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8cmVjdCBmaWxsPSIjRkZGRkZGIiB4PSIwIiB5PSIwIiB3aWR0aD0iMTYiIGhlaWdodD0iMTYiPjwvcmVjdD4KICAgICAgICA8ZyBpZD0icHJvY2VzcyIgb3BhY2l0eT0iMC42IiBmaWxsPSIjNzU3NTc1IiBmaWxsLXJ1bGU9Im5vbnplcm8iPgogICAgICAgICAgICA8cGF0aCBkPSJNOC40MjM1ODUzNSwxMi43NzQyOTI3IEw3LDEyLjA2MjUgTDcsMTAuOTM3NSBMOC40MjM1ODUzNSwxMC4yMjU3MDczIEw3LjkyMDI3MTkyLDguNzE1NzY3MDUgTDguNzE1NzY3MDUsNy45MjAyNzE5MiBMMTAuMjI1NzA3Myw4LjQyMzU4NTM1IEwxMC45Mzc1LDcgTDEyLjA2MjUsNyBMMTIuNzc0MjkyNyw4LjQyMzU4NTM1IEwxNC4yODQyMzMsNy45MjAyNzE5MiBMMTUuMDc5NzI4MSw4LjcxNTc2NzA1IEwxNC41NzY0MTQ3LDEwLjIyNTcwNzMgTDE2LDEwLjkzNzUgTDE2LDEyLjA2MjUgTDE0LjU3NjQxNDcsMTIuNzc0MjkyNyBMMTUuMDc5NzI4MSwxNC4yODQyMzMgTDE0LjI4NDIzMywxNS4wNzk3MjgxIEwxMi43NzQyOTI3LDE0LjU3NjQxNDcgTDEyLjA2MjUsMTYgTDEwLjkzNzUsMTYgTDEwLjIyNTcwNzMsMTQuNTc2NDE0NyBMOC43MTU3NjcwNSwxNS4wNzk3MjgxIEw3LjkyMDI3MTkyLDE0LjI4NDIzMyBMOC40MjM1ODUzNSwxMi43NzQyOTI3IFogTTEuNDIzNTg1MzUsNS43NzQyOTI2NyBMMCw1LjA2MjUgTDAsMy45Mzc1IEwxLjQyMzU4NTM1LDMuMjI1NzA3MzMgTDAuOTIwMjcxOTIsMS43MTU3NjcwNSBMMS43MTU3NjcwNSwwLjkyMDI3MTkyIEwzLjIyNTcwNzMzLDEuNDIzNTg1MzUgTDMuOTM3NSwwIEw1LjA2MjUsMCBMNS43NzQyOTI2NywxLjQyMzU4NTM1IEw3LjI4NDIzMjk1LDAuOTIwMjcxOTIgTDguMDc5NzI4MDgsMS43MTU3NjcwNSBMNy41NzY0MTQ2NSwzLjIyNTcwNzMzIEw5LDMuOTM3NSBMOSw1LjA2MjUgTDcuNTc2NDE0NjUsNS43NzQyOTI2NyBMOC4wNzk3MjgwOCw3LjI4NDIzMjk1IEw3LjI4NDIzMjk1LDguMDc5NzI4MDggTDUuNzc0MjkyNjcsNy41NzY0MTQ2NSBMNS4wNjI1LDkgTDMuOTM3NSw5IEwzLjIyNTcwNzMzLDcuNTc2NDE0NjUgTDEuNzE1NzY3MDUsOC4wNzk3MjgwOCBMMC45MjAyNzE5Miw3LjI4NDIzMjk1IEwxLjQyMzU4NTM1LDUuNzc0MjkyNjcgWiBNNC41LDYuMTg3NSBDNS40MzE5ODA1Miw2LjE4NzUgNi4xODc1LDUuNDMxOTgwNTIgNi4xODc1LDQuNSBDNi4xODc1LDMuNTY4MDE5NDggNS40MzE5ODA1MiwyLjgxMjUgNC41LDIuODEyNSBDMy41NjgwMTk0OCwyLjgxMjUgMi44MTI1LDMuNTY4MDE5NDggMi44MTI1LDQuNSBDMi44MTI1LDUuNDMxOTgwNTIgMy41NjgwMTk0OCw2LjE4NzUgNC41LDYuMTg3NSBaIE0xMS41LDEzLjE4NzUgQzEyLjQzMTk4MDUsMTMuMTg3NSAxMy4xODc1LDEyLjQzMTk4MDUgMTMuMTg3NSwxMS41IEMxMy4xODc1LDEwLjU2ODAxOTUgMTIuNDMxOTgwNSw5LjgxMjUgMTEuNSw5LjgxMjUgQzEwLjU2ODAxOTUsOS44MTI1IDkuODEyNSwxMC41NjgwMTk1IDkuODEyNSwxMS41IEM5LjgxMjUsMTIuNDMxOTgwNSAxMC41NjgwMTk1LDEzLjE4NzUgMTEuNSwxMy4xODc1IFoiIGlkPSJDb21iaW5lZC1TaGFwZSI+PC9wYXRoPgogICAgICAgIDwvZz4KICAgICAgICA8ZyBpZD0icGF1c2UiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUuMDAwMDAwLCAzLjAwMDAwMCkiIGZpbGw9IiNCNzI5NUEiIHN0cm9rZT0iI0ZGRkZGRiI+CiAgICAgICAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGUiIHg9Ii0wLjUiIHk9Ii0wLjUiIHdpZHRoPSIzIiBoZWlnaHQ9IjExIj48L3JlY3Q+CiAgICAgICAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGUiIHg9IjQuNSIgeT0iLTAuNSIgd2lkdGg9IjMiIGhlaWdodD0iMTEiPjwvcmVjdD4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==";
  }

  // src/library/boomiapp/content/listenerGlobal.js
  var add_dialog_listener = (dialog) => {
    if (!dialog.querySelector(".dialogTopCenterInner .Caption").innerText)
      return false;
    let rect = dialog.getBoundingClientRect();
    let children = [...dialog.getElementsByTagName("*")];
  };
  var BoomiPlatform2 = {};
  var bt_init = false;
  var BoomiPlatform_Init = () => {
    dynamicShapeIconStyleData = "";
    if (BoomiPlatform2.shape_icon_styling == "legacy") {
      dynamicShapeIconStyleData = legacyIconData;
    }
    if (BoomiPlatform2.shape_icon_styling == "modern") {
      dynamicShapeIconStyleData = modernIconData;
    }
    if (BoomiPlatform2.shape_icon_styling == "minimal") {
      if (window.getComputedStyle(document.body, null).getPropertyValue("background-color") == "rgb(38, 38, 38)") {
        dynamicShapeIconStyleData = minimalDarkThemeIconData;
      } else {
        dynamicShapeIconStyleData = minimalLightThemeIconData;
      }
    }
    if (BoomiPlatform2.shape_icon_styling == "minimal-inverted") {
      dynamicShapeIconStyleData = minimalInvertedIconStyleColorCodes;
    }
    if (BoomiPlatform2.shape_icon_styling == "refreshed-inverted") {
      dynamicShapeIconStyleData = refreshedIconStyleColorCodes;
    }
    const dom_watcher = (() => {
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.addedNodes) {
            mutation.addedNodes.forEach((node) => {
              try {
                if (typeof dynamicShapeIconStyleData == "object" && node && typeof node === "object" && node !== null && "querySelector" in node) {
                  setTimeout(() => {
                    var elem = node.querySelector(
                      ".shape_palette_widget, .gwt-Shape"
                    );
                    if (elem) {
                      var shapeName = elem.getElementsByTagName("img")[0].title;
                      var shapeImageIcon = dynamicShapeIconStyleData[shapeName];
                      if (shapeImageIcon) {
                        var img = node.getElementsByTagName("img")[0];
                        if (shapeImageIcon.charAt(0) != "#") {
                          if (BoomiPlatform2.shape_icon_styling !== "minimal") {
                            img.style.setProperty("width", "32px", "important");
                            img.style.setProperty("height", "32px", "important");
                            img.style.setProperty(
                              "background-color",
                              "transparent",
                              "important"
                            );
                            elem.style.border = "0px";
                            elem.style.borderRadius = "0px";
                            elem.style.setProperty(
                              "background-color",
                              "transparent",
                              "important"
                            );
                          }
                          img.src = shapeImageIcon;
                        } else {
                          img.style.setProperty("width", "24px", "important");
                          img.style.setProperty("height", "24px", "important");
                          img.style.setProperty(
                            "filter",
                            "none",
                            "important"
                          );
                        }
                      }
                    }
                  }, 0);
                }
                if (node !== null && "querySelector" in node) {
                  let noteForm = node.querySelector(".note-form");
                  if (!noteForm) return false;
                  notegroupbutton_html = `
                                <button type="button" class="NoteGroupButton" onclick="create_note_group(this)">Group</button>
                                `;
                  noteForm.querySelector(".button_row").insertAdjacentHTML("beforeend", notegroupbutton_html);
                  if (/\n{0,2}---\n\#BoomiPlatform: \[\"(\d*px)\"\,\"(\d*px)\"\,\"([a-z]*)\"\]/g.test(
                    noteForm.querySelector("textarea").value
                  )) {
                    setTimeout(() => {
                      create_note_group(noteForm);
                    }, 100);
                  }
                }
              } catch (err) {
                console.error(err);
              }
            });
          }
        });
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    })();
    const global_listeners = setInterval(() => {
      const listenerClass = (selector, callback) => {
        let elements = document.querySelectorAll(
          `${selector}:not(.bph-load-done)`
        );
        if (elements.length) {
          [...elements].forEach((el) => {
            el.classList.add("bph-load-done");
            if (Array.isArray(callback)) {
              callback.forEach((cb) => {
                cb(el);
              });
            } else {
              callback(el);
            }
          });
        }
      };
      listenerClass(".modal_top", modal_listener);
      listenerClass(".gwt-ProcessPanel", [process_to_image, add_canvas_listener]);
      listenerClass(".gwt-EndPoint", add_endpoint_listener);
      listenerClass(".gwt-Shape", add_shape_listener);
      listenerClass(".gwt-connectors-svg", add_path_listener);
      listenerClass(".gwt-DialogBox", add_dialog_listener);
      listenerClass(".boomi_standard_table", add_table_listener);
      listenerClass(".build_actionsButton", add_fullscreen_listener);
      listenerClass(".note-content", add_notecontent_listener);
      listenerClass(".auto_refresh_li", refreshInterval_listener);
      listenerClass(".gwt-DetailAreaInner", add_connector_list);
      listenerClass(".buildMain", add_notification_close);
    }, 1e3);
  };
  chrome.storage.sync.get(null, (config) => {
    BoomiPlatform2 = config;
    if (!bt_init) {
      bt_init = true;
      BoomiPlatform_Init();
    }
  });
  chrome.storage.onChanged.addListener((changes) => {
    for (const [key, { newValue }] of Object.entries(changes)) {
      BoomiPlatform2[key] = newValue;
    }
  });

  // src/library/boomiapp/content/shortcut.js
  shortcut = {
    "all_shortcuts": {},
    //All the shortcuts are stored in this array
    "add": function(shortcut_combination, callback, opt) {
      var default_options = {
        "type": "keydown",
        "propagate": false,
        "disable_in_input": false,
        "target": document,
        "keycode": false
      };
      if (!opt) opt = default_options;
      else {
        for (var dfo in default_options) {
          if (typeof opt[dfo] == "undefined") opt[dfo] = default_options[dfo];
        }
      }
      var ele = opt.target;
      if (typeof opt.target == "string") ele = document.getElementById(opt.target);
      var ths = this;
      shortcut_combination = shortcut_combination.toLowerCase();
      var func = function(e) {
        e = e || window.event;
        if (opt["disable_in_input"]) {
          var element;
          if (e.target) element = e.target;
          else if (e.srcElement) element = e.srcElement;
          if (element.nodeType == 3) element = element.parentNode;
          if (element.tagName == "INPUT" || element.tagName == "TEXTAREA") return;
        }
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        var character = String.fromCharCode(code).toLowerCase();
        if (code == 188) character = ",";
        if (code == 190) character = ".";
        var keys = shortcut_combination.split("+");
        var kp = 0;
        var shift_nums = {
          "`": "~",
          "1": "!",
          "2": "@",
          "3": "#",
          "4": "$",
          "5": "%",
          "6": "^",
          "7": "&",
          "8": "*",
          "9": "(",
          "0": ")",
          "-": "_",
          "=": "+",
          ";": ":",
          "'": '"',
          ",": "<",
          ".": ">",
          "/": "?",
          "\\": "|"
        };
        var special_keys = {
          "esc": 27,
          "escape": 27,
          "tab": 9,
          "space": 32,
          "return": 13,
          "enter": 13,
          "backspace": 8,
          "scrolllock": 145,
          "scroll_lock": 145,
          "scroll": 145,
          "capslock": 20,
          "caps_lock": 20,
          "caps": 20,
          "numlock": 144,
          "num_lock": 144,
          "num": 144,
          "pause": 19,
          "break": 19,
          "insert": 45,
          "home": 36,
          "delete": 46,
          "end": 35,
          "pageup": 33,
          "page_up": 33,
          "pu": 33,
          "pagedown": 34,
          "page_down": 34,
          "pd": 34,
          "left": 37,
          "up": 38,
          "right": 39,
          "down": 40,
          "f1": 112,
          "f2": 113,
          "f3": 114,
          "f4": 115,
          "f5": 116,
          "f6": 117,
          "f7": 118,
          "f8": 119,
          "f9": 120,
          "f10": 121,
          "f11": 122,
          "f12": 123
        };
        var modifiers = {
          shift: { wanted: false, pressed: false },
          ctrl: { wanted: false, pressed: false },
          alt: { wanted: false, pressed: false },
          meta: { wanted: false, pressed: false }
          //Meta is Mac specific
        };
        if (e.ctrlKey) modifiers.ctrl.pressed = true;
        if (e.shiftKey) modifiers.shift.pressed = true;
        if (e.altKey) modifiers.alt.pressed = true;
        if (e.metaKey) modifiers.meta.pressed = true;
        for (var i = 0; k = keys[i], i < keys.length; i++) {
          if (k == "ctrl" || k == "control") {
            kp++;
            modifiers.ctrl.wanted = true;
          } else if (k == "shift") {
            kp++;
            modifiers.shift.wanted = true;
          } else if (k == "alt") {
            kp++;
            modifiers.alt.wanted = true;
          } else if (k == "meta") {
            kp++;
            modifiers.meta.wanted = true;
          } else if (k.length > 1) {
            if (special_keys[k] == code) kp++;
          } else if (opt["keycode"]) {
            if (opt["keycode"] == code) kp++;
          } else {
            if (character == k) kp++;
            else {
              if (shift_nums[character] && e.shiftKey) {
                character = shift_nums[character];
                if (character == k) kp++;
              }
            }
          }
        }
        if (kp == keys.length && modifiers.ctrl.pressed == modifiers.ctrl.wanted && modifiers.shift.pressed == modifiers.shift.wanted && modifiers.alt.pressed == modifiers.alt.wanted && modifiers.meta.pressed == modifiers.meta.wanted) {
          callback(e);
          if (!opt["propagate"]) {
            e.cancelBubble = true;
            e.returnValue = false;
            if (e.stopPropagation) {
              e.stopPropagation();
              e.preventDefault();
            }
            return false;
          }
        }
      };
      this.all_shortcuts[shortcut_combination] = {
        "callback": func,
        "target": ele,
        "event": opt["type"]
      };
      if (ele.addEventListener) ele.addEventListener(opt["type"], func, false);
      else if (ele.attachEvent) ele.attachEvent("on" + opt["type"], func);
      else ele["on" + opt["type"]] = func;
    },
    //Remove the shortcut - just specify the shortcut and I will remove the binding
    "remove": function(shortcut_combination) {
      shortcut_combination = shortcut_combination.toLowerCase();
      var binding = this.all_shortcuts[shortcut_combination];
      delete this.all_shortcuts[shortcut_combination];
      if (!binding) return;
      var type = binding["event"];
      var ele = binding["target"];
      var callback = binding["callback"];
      if (ele.detachEvent) ele.detachEvent("on" + type, callback);
      else if (ele.removeEventListener) ele.removeEventListener(type, callback, false);
      else ele["on" + type] = false;
    }
  };
})();
